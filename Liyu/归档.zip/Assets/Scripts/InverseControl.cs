using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InverseControl : MonoBehaviour
{
    public GameObject Fish1;
    public GameObject Fish2;
    // Start is called before the first frame update
    private void Start()
    {
      
        
    }
    private void Update()
    {
       
    }
    public void DestroyMyself()
    {
        Destroy(this.gameObject);
    }
    // Update is called once per frame
   
}
